'use strict';
const assert=require('node:assert/strict');
const {performance}=require('node:perf_hooks');
const {Simulation}=require('../server/simulation.cjs');
const {createHost}=require('../server.js');
const WebSocket=require('../server/vendor/ws');
const version=require('../package.json').version;
let passed=0;const results=[];
function check(name,fn){fn();passed++;results.push(name);console.log('PASS',name);}
const members=[{id:'a',name:'Alpha'},{id:'b',name:'Beta'},{id:'c',name:'Charlie'},{id:'d',name:'Delta'}];
function world(n=2){const s=new Simulation(members.slice(0,n),123456);s.inspect("WORLD.buildings=[];WORLD.road=[];Town.clearDecor();state.nextBossTime=1e6;state.airdropTimer=1e6;state.militaryAirdropTimer=1e6;state.spawnTimer=-1e6;");return s;}
function run(s,count,inputs={}){for(let i=0;i<count;i++){for(const [id,input] of Object.entries(inputs))s.input(id,{keys:[],fire:false,aimX:2000,aimY:1200,...input});s.step();}}
check('Seeded towns and room state are independent',()=>{
 const a=new Simulation(members.slice(0,2),500),b=new Simulation(members.slice(0,2),500),c=new Simulation(members.slice(0,2),501);
 const geometry='JSON.stringify([WORLD.buildings,Town.props,WORLD.road])';assert.equal(a.inspect(geometry),b.inspect(geometry));assert.notEqual(a.inspect(geometry),c.inspect(geometry));a.inspect('state.score=999;Coop.all()[0].hp=1');assert.equal(b.inspect('state.score'),0);assert.equal(b.inspect('Coop.all()[0].hp'),100);
});
check('Independent movement, normalized diagonals and stale input timeout',()=>{
 const s=world();const before=s.snapshot().players;s.input('a',{keys:['d'],fire:false,aimX:2100,aimY:1200});run(s,30);const p=s.snapshot().players;assert.ok(Math.abs(p[0].x-before[0].x-87.5)<.02);assert.equal(p[1].x,before[1].x);
 const t=world();const q=t.snapshot().players[0];run(t,30,{a:{keys:['w','d']}});const end=t.snapshot().players[0];assert.ok(Math.abs(Math.hypot(end.x-q.x,end.y-q.y)-175)<.03);
});
check('Server weapon cooldown, magazine and reload are player-specific',()=>{
 const s=world();run(s,40,{a:{fire:true}});let p=s.snapshot().players;assert.equal(p[0].mag,3);assert.equal(p[1].mag,6);s.input('a',{keys:[],fire:false,aimX:2100,aimY:1200,actions:['reload']});run(s,45);p=s.snapshot().players;assert.equal(p[0].mag,6);assert.equal(p[1].mag,6);
});
check('Quick mouse/roll taps are latched even when key-up arrives before the next tick',()=>{const s=world();s.input('a',{keys:['d'],fire:false,aimX:2000,aimY:1200,actions:['shoot','dash']});s.step();const p=s.snapshot().players;assert.equal(p[0].mag,5);assert.ok(p[0].dashCooldown>1);assert.equal(p[1].mag,6);});
check('Shotgun pellets kill once and carry death animation events',()=>{
 const s=world();s.inspect("const p=Coop.all()[0];state.zombies=[{id:10,type:'walker',x:p.x+65,y:p.y,...zombieBase('walker'),hp:1,speed:0}];");run(s,8,{a:{fire:true,aimX:1900,aimY:1176}});const v=s.snapshot();assert.equal(v.world.kills,1);assert.equal(v.events.filter(e=>e.type==='death'&&e.data.z.id===10).length,1);
});
check('Pickup contention chooses one eligible player; full inventory does not attract',()=>{
 const s=world();s.inspect("Coop.all()[0].grenades=8;Coop.all()[1].grenades=0;state.pickups=[{type:'grenade',x:1800,y:1176,radius:8,ttl:40}];");run(s,30);let v=s.snapshot();assert.equal(v.players[0].grenades,8);assert.equal(v.players[1].grenades,1);assert.equal(v.world.pickups.length,0);
 s.inspect("Coop.all().forEach(p=>p.hp=p.maxHp);state.pickups=[{type:'med',x:1800,y:1176,radius:8,ttl:40}];");run(s,15);v=s.snapshot();assert.equal(v.world.pickups[0].x,1800);assert.equal(v.world.pickups[0].ttl,39.5);
});
check('Airdrop equipment is claimed once and assigned to its recipient',()=>{
 const s=world();s.inspect("state.airdrops=[{kind:'military',loot:'drone',x:Coop.all()[1].x,y:Coop.all()[1].y,landed:true,smoke:0}];");run(s,1);const v=s.snapshot();assert.equal(v.world.airdrops.length,0);assert.equal(v.arsenal.drones.length,1);assert.equal(v.arsenal.drones[0].ownerId,'b');
});
check('Boss slam damages and pushes all nearby survivors, pushes zombies without damage',()=>{
 const s=world();s.inspect("const b={id:1,type:'boss',...zombieBase('boss'),x:1800,y:1176,targetX:1800,targetY:1176,bossPhase:'airborne',bossTimer:.001,startX:1800,startY:1176};const z={id:2,type:'walker',x:1850,y:1176,...zombieBase('walker'),hp:100};state.zombies=[b,z];BossAttack.update(b,.01);");const v=s.snapshot();for(const p of v.players){assert.equal(p.hp,68);assert.ok(p.knockbackTime>0);}assert.equal(v.world.zombies[1].hp,100);assert.ok(v.world.zombies[1].slamPushTime>0);
});
check('Grenade splash applies once per survivor, not once per roster member',()=>{
 const s=world(4);s.inspect("Coop.all().forEach(p=>{p.x=1800;p.y=1200;});explode({x:1800,y:1200,damageMul:1},'normal');");for(const p of s.snapshot().players)assert.equal(p.hp,84.38);
});
check('Burn statuses tick independently; burning bloater ignites actors without a fire zone',()=>{
 const s=world();s.inspect('Coop.all().forEach(p=>Burning.ignite(p));Burning.update(1);');for(const p of s.snapshot().players)assert.equal(p.hp,96);
 s.inspect("state.zombies=[{id:33,type:'bloater',...zombieBase('bloater'),x:1800,y:1176,hp:0,burn:{mult:1}}];handleZombieDeath(0,true,'fire');");const v=s.snapshot();assert.equal(v.world.fireZones.length,0);assert.ok(v.players.every(p=>p.burn));assert.ok(v.events.some(e=>e.type==='death'&&e.data.cause==='fire'));
});
check('Lightning damages all players in its radius',()=>{
 const s=world();s.inspect('Weather.forceStrike(1800,1176,{radius:60,playerDamage:35,zombieDamage:0});');assert.ok(s.snapshot().players.every(p=>p.hp===65));
});
check('Three drones per owner, independent magazines, patrol and expiry',()=>{
 const s=world();s.inspect("Coop.each(()=>{for(let i=0;i<4;i++)Arsenal.deploy();});");let v=s.snapshot();assert.equal(v.arsenal.drones.length,6);assert.equal(v.arsenal.drones.filter(d=>d.ownerId==='a').length,3);s.inspect("Coop.all()[0].x=1200;Coop.all()[1].x=2400;state.zombies=[{id:9,type:'walker',x:2440,y:1230,...zombieBase('walker'),hp:10000,speed:0}];");run(s,90);v=s.snapshot();assert.ok(v.arsenal.drones.filter(d=>d.ownerId==='a').every(d=>d.x<1550));assert.ok(v.arsenal.drones.filter(d=>d.ownerId==='b').every(d=>d.x>2000));assert.ok(v.arsenal.drones.some(d=>d.ownerId==='b'&&(d.mag<10||d.reload>0)));s.inspect('Arsenal.drones.forEach(d=>d.life=.01)');run(s,1);assert.equal(s.snapshot().arsenal.drones.length,0);
});
check('Arc chain limit and line of sight remain authoritative',()=>{
 const s=world();s.inspect("Coop.withPlayer(Coop.all()[0],()=>{player.x=1400;player.y=1200;for(let i=0;i<14;i++)state.zombies.push({id:i+1,type:'walker',x:1510+i*36,y:1192,...zombieBase('walker'),hp:1000,speed:0});Arsenal.electric({x:1430,y:1192},0,1);});");assert.equal(s.inspect('state.zombies.filter(z=>z.hp<1000).length'),10);
});
check('Individual death does not end the match; team wipe does; disconnected actors retire',()=>{
 const s=world();s.inspect('Coop.withPlayer(Coop.all()[0],()=>damagePlayer(1000));');let v=s.snapshot();assert.equal(v.world.running,true);assert.equal(v.players[0].hp,0);assert.equal(v.events.filter(e=>e.type==='playerDeath').length,1);s.disconnect('b');v=s.snapshot();assert.equal(v.world.gameOver,true);assert.equal(v.world.running,false);assert.equal(v.players[1].connected,false);run(s,3);
});
check('Enemies pursue the closest living survivor',()=>{
 const s=world();s.inspect("Coop.all()[0].x=600;Coop.all()[1].x=2300;state.zombies=[{id:91,type:'walker',x:2400,y:1176,...zombieBase('walker'),speed:50}];");run(s,10);assert.equal(s.inspect('state.zombies[0].targetPlayerId'),'b');assert.ok(s.inspect('state.zombies[0].x')<2400);
});
function delay(ms){return new Promise(r=>setTimeout(r,ms));}
async function socketClient(url,name,build=version){
 const ws=new WebSocket(url),queue=[];ws.on('message',b=>queue.push(JSON.parse(b)));
 await new Promise((resolve,reject)=>{ws.once('open',resolve);ws.once('error',reject);});
 const c={ws,send:m=>ws.send(JSON.stringify(m)),queue,async wait(type,pred=()=>true,timeout=6000){const until=Date.now()+timeout;while(Date.now()<until){const i=queue.findIndex(m=>m.type===type&&pred(m));if(i>=0)return queue.splice(i,1)[0];await delay(10);}throw Error('Timeout '+name+' '+type+' '+JSON.stringify(queue.slice(-2)));}};
 c.send({type:'hello',version:build,name});if(build===version)c.id=(await c.wait('welcome')).id;return c;
}
async function online(){
 const app=createHost({maxRooms:4}),address=await app.listen(0,'127.0.0.1'),base='http://127.0.0.1:'+address.port,url=base.replace('http','ws')+'/ws',sockets=[];
 try{
  const bad=await socketClient(url,'Old','0.0.0');sockets.push(bad);assert.equal((await bad.wait('error')).code,'version');bad.ws.close();
  const a=await socketClient(url,'Alpha'),b=await socketClient(url,'Beta'),c=await socketClient(url,'Charlie'),d=await socketClient(url,'Delta');sockets.push(a,b,c,d);
  a.send({type:'create',name:'Private A',capacity:2,password:'secret'});const roomA=(await a.wait('room')).room;
  b.send({type:'join',id:roomA.id,password:'wrong'});assert.equal((await b.wait('error')).code,'password');await delay(720);b.send({type:'join',id:roomA.id,password:'secret'});await b.wait('room');
  c.send({type:'create',name:'Room B',capacity:2,password:''});const roomB=(await c.wait('room')).room;d.send({type:'join',id:roomB.id});await d.wait('room');
  b.send({type:'start'});assert.equal((await b.wait('error')).code,'host_only');a.send({type:'start'});assert.equal((await a.wait('error')).code,'not_ready');
  for(const p of [a,b,c,d])p.send({type:'ready'});await a.wait('room',m=>m.room.members.length===2&&m.room.members.every(p=>p.ready));await c.wait('room',m=>m.room.members.length===2&&m.room.members.every(p=>p.ready));a.send({type:'start'});c.send({type:'start'});
  const [sa,sb,sc,sd]=await Promise.all([a,b,c,d].map(p=>p.wait('start')));assert.deepEqual(sa.snapshot,sb.snapshot);assert.deepEqual(sc.snapshot,sd.snapshot);assert.notEqual(sa.snapshot.seed,sc.snapshot.seed);
  check('Real WebSockets: version, password, ready gate, host controls and two isolated rooms',()=>{});
  // Inputs contain forged HP/position/damage; only allowed intent fields are used.
  let seq=0;const timer=setInterval(()=>a.send({type:'input',seq:++seq,keys:['d'],aimX:2100,aimY:1200,fire:true,x:0,hp:999999,damage:999999,dt:100}),33);
  const shot=await a.wait('snapshot',m=>m.snapshot.players.find(p=>p.id===a.id).mag<6);const same=await b.wait('snapshot',m=>m.snapshot.tick===shot.snapshot.tick);assert.deepEqual(shot.snapshot,same.snapshot);
  await delay(350);clearInterval(timer);a.send({type:'input',seq:++seq,keys:[],aimX:2100,aimY:1200,fire:false});const moved=await a.wait('snapshot',m=>m.snapshot.tick>shot.snapshot.tick+10);const ap=moved.snapshot.players.find(p=>p.id===a.id),bp=moved.snapshot.players.find(p=>p.id===b.id);assert.ok(ap.x>sa.snapshot.players[0].x);assert.equal(ap.hp,100);assert.equal(bp.x,sa.snapshot.players[1].x);assert.equal(bp.mag,6);
  const unaffected=await c.wait('snapshot',m=>m.snapshot.tick>moved.snapshot.tick);assert.ok(unaffected.snapshot.players.every(p=>p.mag===6));assert.ok(!unaffected.snapshot.players.some(p=>p.id===a.id));
  check('Real WebSockets: exact peer snapshots, independent input/ammo, forged state rejected',()=>{});
  a.send({type:'leave'});const transfer=(await b.wait('room',m=>m.room.hostId===b.id&&m.room.count===1)).room;assert.equal(transfer.status,'playing');await b.wait('snapshot',m=>m.snapshot.players.find(p=>p.id===a.id).connected===false&&m.snapshot.world.running);
  b.send({type:'leave'});await b.wait('left');await delay(100);assert.ok(!app.rooms.has(roomA.id));
  c.ws.close();await d.wait('room',m=>m.room.hostId===d.id&&m.room.count===1);await d.wait('snapshot',m=>m.snapshot.players.find(p=>p.id===c.id).hp===0);
  check('Real WebSockets: leader transfer, disconnected death, survivor continues, empty-room cleanup',()=>{});
  // Drive the private worker's existing disconnect event; no debug network API.
  app.rooms.get(roomB.id).worker.postMessage({type:'disconnect',id:d.id});
  await d.wait('room',m=>m.room.status==='ended');d.send({type:'rematch'});await d.wait('reset');await d.wait('room',m=>m.room.status==='waiting');d.send({type:'ready'});await d.wait('room',m=>m.room.members.every(p=>p.ready));d.send({type:'start'});const restarted=await d.wait('start');assert.equal(restarted.snapshot.players.length,1);assert.equal(restarted.snapshot.players[0].hp,100);assert.equal(restarted.snapshot.world.score,0);
  check('Real WebSockets: team-wipe report and clean rematch in the same room',()=>{});
  assert.equal((await fetch(base+'/')).status,200);assert.equal((await fetch(base+'/network.js')).status,200);assert.equal((await fetch(base+'/server.js')).status,404);assert.equal((await fetch(base+'/server/world.js')).status,404);assert.equal((await fetch(base+'/package.json')).status,404);
  await new Promise((resolve,reject)=>{const evil=new WebSocket(url,{origin:'https://unrelated.example'});evil.on('unexpected-response',(_,res)=>{assert.equal(res.statusCode,403);res.resume();evil.terminate();resolve();});evil.on('error',()=>{});evil.on('open',()=>reject(Error('Cross-origin accepted')));});
  check('HTTP static allowlist and WebSocket origin restrictions',()=>{});
 }finally{for(const c of sockets)c.ws.terminate();await app.close();}
}
online().then(()=>console.log(JSON.stringify({passed,results},null,2))).catch(e=>{console.error(e);process.exitCode=1;});
