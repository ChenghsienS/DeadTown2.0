# V1.1.4 — In-game notice styling

Changed the shared announcement renderer to match the existing menu and HUD:
dark olive panels, one-pixel borders, hard shadows, off-white monospace text,
pixel icons, olive supply/upgrade accents, and red military/threat accents.
Only active notices occupy space. Card width adapts to the viewport and text
fits without horizontal glyph stretching. The existing timers drive the thin
remaining-time line and final 0.24-second fade.

Validation performed with the real game scripts and @napi-rs/canvas:

- Rendered normal/military airdrops, serum upgrades, equipment pickups, and
  simultaneous Boss/supply/upgrade notices in English and Chinese.
- Visually inspected 1280×720 game rendering and a 320-pixel-wide notice stack.
- Exercised actual serum and equipment handlers; confirmed upgrade effects,
  weapon selection, and notice categories.
- Confirmed drawing restores the canvas alignment, opacity, and rendered fill
  color; verified pause/resume freezes and resumes notice timers.
- Confirmed restart clears notices and the main menu displays BUILD V1.1.4.
- All 19 JavaScript files passed the existing syntax check.
- Reviewed the code diff: gameplay changes are limited to notice category
  metadata. No leaderboard or multiplayer code was modified.

The preview harness supplies a simulated DOM. Native Canvas screenshots do not
include the HTML HUD. Nimbus Mono and Noto Sans CJK were registered as preview
font substitutes; the game continues to use the existing system-font stack.
No real-browser gameplay, CSS layout, or device FPS measurement was performed.

See NOTICES-V1.1.4.png for the English/Chinese notice samples.
