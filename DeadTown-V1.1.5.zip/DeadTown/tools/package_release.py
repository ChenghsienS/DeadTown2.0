"""Create an offline release; sync the home screen's version from package.json.

Run: python3 tools/package_release.py [output-directory]
"""
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import zipfile

root = Path(__file__).resolve().parent.parent
version = json.loads((root / 'package.json').read_text())['version']
if not re.fullmatch(r'\d+\.\d+\.\d+(?:-[A-Za-z0-9.-]+)?', version):
    raise SystemExit('Invalid package version')
# Project version components use radix-15 rollover: 1.0.14 -> 1.1.0.
if any(int(part) >= 15 for part in version.split('-')[0].split('.')):
    raise SystemExit('Version components must be 0-14 (radix-15 rollover)')
(root / 'version.js').write_text(
    '// Generated from package.json by tools/package_release.py. Do not edit separately.\n'
    f"const GAME_VERSION = '{version}';\n", encoding='utf-8')
destination = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root.parent
if destination == root or root in destination.parents:
    raise SystemExit('Choose an output directory outside the project')
destination.mkdir(parents=True, exist_ok=True)
target = destination / f'DeadTown-V{version}.zip'
if target.exists():
    raise SystemExit(f'Release already exists: {target.name}. Use a new version or directory.')
fd, temporary = tempfile.mkstemp(prefix='.deadtown-', suffix='.zip', dir=destination)
try:
    with os.fdopen(fd, 'wb') as stream:
        with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for file in sorted(root.rglob('*')):
                relative = file.relative_to(root)
                if file.is_file() and not any(part.startswith('.') or part in ('node_modules', '__pycache__') for part in relative.parts):
                    archive.write(file, Path('DeadTown') / relative)
        stream.flush()
        os.fsync(stream.fileno())
    with zipfile.ZipFile(temporary) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f'Archive CRC failed: {bad}')
    os.replace(temporary, target)
    if hasattr(os, 'O_DIRECTORY'):
        directory_fd = os.open(destination, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    print(target)
finally:
    if os.path.exists(temporary):
        os.unlink(temporary)
