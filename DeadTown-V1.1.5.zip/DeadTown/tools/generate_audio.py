"""Generate original layered Foley/weapon audio and an offline-ready PCM bank.
Run with Python 3; uses only the standard library. No recordings are required.
"""
from pathlib import Path
import math,random,wave,struct,base64,json
SR=32000
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/audio'
OUT.mkdir(parents=True,exist_ok=True)
rng=random.Random(812117)

def noise(n): return [rng.uniform(-1,1) for _ in range(n)]
def low(x,hz):
 a=1-math.exp(-2*math.pi*hz/SR);y=0;out=[]
 for v in x:
  y+=a*(v-y);out.append(y)
 return out

def band(x,lo,hi):
 a=low(x,hi);b=low(a,lo)
 return [v-w for v,w in zip(a,b)]

def env(t,decay,attack=0.001):return min(1,t/attack)*math.exp(-t/decay)
def zeros(sec):return [0.] * int(sec*SR)
def put(dst,src,at=0,gain=1):
 k=int(at*SR)
 for j,v in enumerate(src):
  if 0<=j+k<len(dst):dst[j+k]+=v*gain

def resonance(sec,freq,decay):
 return [math.sin(2*math.pi*freq*i/SR)*env(i/SR,decay) for i in range(int(sec*SR))]

def mechanical(sec=0.16):
 x=noise(int(sec*SR));h=band(x,700,6500);l=low(x,650)
 return [(h[i]*0.7+l[i]*1.3+math.sin(i/SR*2*math.pi*1730)*0.06)*env(i/SR,0.023,0.0008) for i in range(len(x))]

def shot(kind):
 sec=0.95 if kind=='shotgun' else 0.25
 n=int(sec*SR);x=noise(n);mid=band(x,140,6200);bass=low(x,190);snap=band(noise(n),2200,9500)
 out=[]
 for i in range(n):
  t=i/SR
  if kind=='shotgun':v=mid[i]*env(t,0.09)*1.5+bass[i]*env(t,0.21)*3.7+snap[i]*env(t,0.009)*0.75
  else:v=mid[i]*env(t,0.028)*1.4+bass[i]*env(t,0.065)*2.9+snap[i]*env(t,0.004)*0.55
  out.append(v)
 dry=out[:];put(out,low(dry,1800),0.046,0.13);put(out,low(dry,1100),0.103,0.055)
 put(out,mechanical(),0.12 if kind=='shotgun' else 0.07,0.15)
 return out

def explosion():
 n=int(2.4*SR);x=noise(n);body=low(x,340);sub=low(x,65);crack=band(x,700,6200);tail=low(noise(n),1400)
 out=[]
 for i in range(n):
  t=i/SR
  out.append(body[i]*env(t,0.44)*2.8+sub[i]*env(t,0.68)*5.5+crack[i]*env(t,0.035)*0.7+tail[i]*env(t,0.64,0.06)*0.6)
 dry=out[:];put(out,low(dry,850),0.13,0.22);put(out,low(dry,550),0.25,0.10)
 return out

def rocket():
 out=zeros(1.05);put(out,mechanical(0.2),gain=0.6)
 x=band(noise(len(out)),80,2300)
 for i,v in enumerate(x):
  t=i/SR;out[i]+=v*env(max(0,t-0.014),0.24,0.025)*1.6
 return out

def glass():
 out=zeros(0.72)
 for _ in range(24):
  f=rng.uniform(1700,7200);at=rng.uniform(0,0.25)
  put(out,resonance(0.2,f,rng.uniform(0.008,0.04)),at,rng.uniform(0.05,0.2))
 put(out,mechanical(0.1),gain=0.2)
 return out

def impact(wet=False):
 n=int((0.33 if wet else 0.15)*SR);x=noise(n);body=low(x,350);h=band(x,800,3600)
 return [(body[i]*3.0*env(i/SR,0.07)+h[i]*0.32*env(i/SR,0.012))*(1+0.15*math.sin(i/SR*260)) for i in range(n)]

def step(material):
 sec={'concrete':0.28,'wood':0.43,'grass':0.36}[material];n=int(sec*SR)
 out=zeros(sec);x=noise(n);sole=low(x,210)
 if material=='concrete':
  # Hard heel contact, a smaller toe slap, and a short gritty sole scrape.
  snap=low(band(x,850,5400),5400);grit=band(noise(n),1500,4700)
  for i in range(n):
   t=i/SR;out[i]=sole[i]*2.6*env(t,0.021)+snap[i]*0.75*env(t,0.009)
  toe=low(band(noise(int(SR*0.09)),550,4800),5400)
  put(out,[v*env(i/SR,0.012)*0.5 for i,v in enumerate(toe)],rng.uniform(0.047,0.065))
  for i in range(n):
   t=i/SR
   if t>0.06:out[i]+=grit[i]*0.13*env(t-0.06,0.035,0.008)
 elif material=='wood':
  # A hollow board knock with several damped, non-harmonic resonances.
  knock=band(x,350,2300)
  for i in range(n):
   t=i/SR;out[i]=sole[i]*2.3*env(t,0.047)+knock[i]*0.38*env(t,0.011)
  tuning=rng.uniform(0.92,1.08)
  for freq,gain,decay in [(118,0.26,0.075),(227,0.14,0.053),(419,0.07,0.037)]:
   put(out,resonance(0.3,freq*tuning,decay),gain=gain)
  toe=low(noise(int(SR*0.14)),550)
  put(out,[v*env(i/SR,0.027)*1.1 for i,v in enumerate(toe)],rng.uniform(0.06,0.09))
  # Faint board friction after loading; deliberately softer than the knock.
  rasp=band(noise(n),400,1600)
  for i in range(n):
   t=i/SR
   if t>0.075:out[i]+=rasp[i]*0.2*env(t-0.075,0.07,0.025)*(0.65+0.35*math.sin(t*190)**2)
 else:
  # Soft earth pressure, followed by damp grass blades brushing the sole.
  rustle=band(noise(n),650,3400);moss=low(noise(n),380)
  for i in range(n):
   t=i/SR;out[i]=sole[i]*1.6*env(t,0.038,0.012)+moss[i]*0.25*env(t,0.07,0.025)+rustle[i]*0.2*env(t,0.085,0.025)
  for _ in range(12):
   leaf=band(noise(int(SR*0.055)),850,4300)
   put(out,[v*env(i/SR,0.012,0.003) for i,v in enumerate(leaf)],rng.uniform(0.018,0.22),rng.uniform(0.06,0.16))
 return out

def looped(x):
 k=int(SR*0.18);tail=x[-k:];head=x[:k]
 return x[k:-k]+[tail[i]*(1-i/k)+head[i]*(i/k) for i in range(k)]

def fire(jet=False):
 sec=3.5;n=int(sec*SR);x=noise(n);body=band(x,70,2400 if jet else 1400);lowend=low(x,180);out=[]
 for i in range(n):
  t=i/SR;mod=0.85+0.08*math.sin(t*11.7)+0.05*math.sin(t*23.9)
  out.append((body[i]*1.1+lowend[i]*1.7)*mod)
 if not jet:
  for _ in range(38):put(out,mechanical(0.06),rng.uniform(0,sec-0.1),rng.uniform(0.08,0.35))
 return looped(out)

def weapon_impact(kind):
 sec={'shotgun':0.31,'gatling':0.12,'rocket':0.48,'grenade':0.34,'flame':0.26,'burn':0.35}[kind]
 n=int(SR*sec);x=noise(n);body=low(x,260);flesh=band(x,460,2300);detail=band(noise(n),1600,5400)
 out=zeros(sec)
 if kind in ('flame','burn'):
  # Moist sizzling and tiny crackles; no gun-like impact during continuous burn.
  for i in range(n):
   t=i/SR;out[i]=(flesh[i]*0.26+detail[i]*0.32)*env(t,0.07 if kind=='flame' else 0.11,0.015)
  for _ in range(5 if kind=='flame' else 9):put(out,mechanical(0.035),rng.uniform(0.012,sec*0.7),rng.uniform(0.015,0.045))
 else:
  decay={'shotgun':0.063,'gatling':0.023,'rocket':0.12,'grenade':0.075}[kind]
  bass={'shotgun':3.8,'gatling':2.8,'rocket':5.2,'grenade':3.5}[kind]
  for i in range(n):
   t=i/SR;out[i]=body[i]*bass*env(t,decay)+flesh[i]*0.5*env(t,decay*0.45)+detail[i]*0.16*env(t,0.006)
  for _ in range({'shotgun':6,'gatling':1,'rocket':4,'grenade':7}[kind]):
   put(out,impact(True),rng.uniform(0.006,0.065 if kind!='gatling' else 0.012),rng.uniform(0.05,0.2))
 return out

def flame_jet(sec=4.8):
 n=int(sec*SR);x=noise(n);combustion=band(x,80,1300);pressure=band(noise(n),500,3800);flutter=low(noise(n),9)
 # Broad turbulent combustion plus a restrained pressurized nozzle hiss.
 return [(combustion[i]*1.8+pressure[i]*0.28)*(0.88+max(-0.18,min(0.18,flutter[i]*3.5))) for i in range(n)]

def flame_edge(ignite):
 sec=0.46 if ignite else 0.3;out=flame_jet(sec)
 for i in range(len(out)):
  t=i/SR
  out[i]*=env(t,0.13,0.035) if ignite else math.exp(-t/0.07)
 if ignite:
  put(out,mechanical(0.08),0,0.3)
  puff=low(noise(int(SR*0.22)),240)
  put(out,[v*env(i/SR,0.065,0.012)*3 for i,v in enumerate(puff)],0.055)
 else:put(out,mechanical(0.06),0.08,0.12)
 return out

def rain():
 sec=10;n=int(SR*sec);bed=band(noise(n),550,5600);soft=band(noise(n),180,1600)
 out=[bed[i]*0.36+soft[i]*0.15 for i in range(n)]
 # Subtle individual drops on wet pavement; avoid wind rumble and metallic hiss.
 for _ in range(150):
  drop=band(noise(int(SR*0.045)),500,4300)
  drop=[v*env(i/SR,0.009,0.0015) for i,v in enumerate(drop)]
  put(out,drop,rng.uniform(0,sec-0.06),rng.uniform(0.04,0.15))
 return looped(out)

def thunder(near):
 sec=rng.uniform(4.6,5.6) if near else rng.uniform(5.6,6.8);n=int(SR*sec)
 rumble=low(noise(n),180);body=band(noise(n),80,650);out=zeros(sec)
 for i in range(n):
  t=i/SR;out[i]=(rumble[i]*3+body[i]*0.8)*env(t,1.1 if near else 1.6,0.05 if near else 0.45)
 for _ in range(9):
  length=rng.uniform(0.3,0.9);roll=low(noise(int(SR*length)),rng.uniform(130,450))
  roll=[v*math.sin(math.pi*i/len(roll))**1.5 for i,v in enumerate(roll)]
  at=rng.uniform(0.12,sec-1);put(out,roll,at,0.8*math.exp(-at/2.5))
 if near:
  crack=band(noise(int(SR*0.28)),250,2800)
  put(out,[v*env(i/SR,0.035,0.003) for i,v in enumerate(crack)],0,0.95)
 return out

def groan():
 sec=1.2;n=int(sec*SR);air=low(noise(n),700);out=[];f=rng.uniform(65,93);phase=0
 for i in range(n):
  t=i/SR;phase+=2*math.pi*(f+7*math.sin(t*7.0)+4*math.sin(t*19))/SR
  voice=(math.sin(phase)+0.24*math.sin(phase*2.02)+0.12*math.sin(phase*3.04))*0.35
  out.append((voice+air[i]*0.9)*math.sin(math.pi*t/sec)**1.6)
 return out

bank={};stats=[]
def save(name,x,peak=0.74,isloop=False):
 mean=sum(x)/len(x);x=[v-mean for v in x];top=max(abs(v) for v in x) or 1
 x=[v*peak/top for v in x]
 if not isloop:
  k=min(int(SR*0.012),len(x)//4)
  for i in range(k):x[-i-1]*=i/k
  for i in range(min(20,len(x))):x[i]*=i/20
 pcm=struct.pack('<'+'h'*len(x),*[round(max(-0.98,min(0.98,v))*32767) for v in x])
 with wave.open(str(OUT/(name+'.wav')),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(SR);f.writeframes(pcm)
 bank[name]=base64.b64encode(pcm).decode()
 stats.append((name,round(len(x)/SR,2),round(max(abs(v) for v in x),3)))

for i in range(1,4):save('shotgun_'+str(i),shot('shotgun'))
for i in range(1,5):save('gatling_'+str(i),shot('gatling'))
for i in range(1,3):save('rocket_'+str(i),rocket());save('explosion_'+str(i),explosion(),0.78)
for kind,duration,times in [('shotgun',1.3,[0.03,0.28,0.58,0.9,1.12]),('gatling',1.9,[0.02,0.45,1.15,1.52]),('rocket',0.95,[0.03,0.42,0.74]),('flamethrower',1.0,[0.02,0.4,0.78])]:
 out=zeros(duration)
 for t in times:put(out,mechanical(0.18),t,rng.uniform(0.5,1))
 save('reload_'+kind,out,0.55)
for i in range(1,4):
 save('hit_'+str(i),impact());save('gore_'+str(i),impact(True))
 # Preserve the old RNG positions so unrelated combat/weather assets stay identical.
 for _ in range(2*int(0.3*SR)):rng.random()
 save('groan_'+str(i),groan(),0.55)
save('glass',glass(),0.6)
save('pickup',mechanical(0.25),0.45)
save('click',mechanical(0.09),0.35)
save('throw',mechanical(0.18),0.45)
x=band(noise(int(SR*0.36)),150,2500);save('roll',[v*math.sin(math.pi*i/len(x))**1.5 for i,v in enumerate(x)],0.52)
save('flame_loop',looped(flame_jet()),0.58,True)
save('flame_ignite',flame_edge(True),0.58);save('flame_release',flame_edge(False),0.44)
save('fire_loop',fire(),0.62,True);save('rain_loop',rain(),0.34,True)
for kind in ('shotgun','gatling','rocket','grenade','flame','burn'):
 for i in range(1,4):save('impact_'+kind+'_'+str(i),weapon_impact(kind),0.65 if kind not in ('flame','burn') else 0.48)
for i in range(1,4):
 save('thunder_distant_'+str(i),thunder(False),0.56)
 save('thunder_strike_'+str(i),thunder(True),0.66)
# Footsteps have their own deterministic stream, independent of combat/weather.
rng=random.Random(430187)
for material,peak in [('concrete',0.58),('wood',0.56),('grass',0.46)]:
 for i in range(1,5):save('step_'+material+'_'+str(i),step(material),peak)
# Remove retired generated samples, including the old wind ambience.
for file in OUT.glob('*.wav'):
 if file.stem not in bank:file.unlink()
(ROOT/'assets/audio-bank.js').write_text('// Generated by tools/generate_audio.py. Mono signed PCM16; embedded for file:// play.\nconst DEADTOWN_AUDIO_BANK='+json.dumps({'sampleRate':SR,'samples':bank},separators=(',',':'))+';\n')
print('Generated',len(bank),'original WAV assets; duration',round(sum(t[1] for t in stats),1),'seconds; max sample peak',max(t[2] for t in stats))
